<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Magazin Machiaj</title>
    <link rel="stylesheet" href="stilizare pag pornire, logare si creare cont.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <h1>Make-up</h1>

    <h2>Categorii de produse</h2>

    <div class="categorii-container">

        <p>
            <a href="categorii produse/pagina fond de ten.html">
                <img src="imagini/fond de ten.jpg" alt="Fond de ten" width="200"><br>
                Fond de ten
            </a>
        </p>

        <p>
            <a href="categorii produse/pag rujuri.html">
                <img src="imagini\ruj.jpg" alt="Ruj" width="200"><br>
                Ruj
            </a>
        </p>

        <p>
            <a href="categorii produse/pagina fard de ochi.html">
                <img src="imagini\farduri ochi.jpg" alt="Fard de pleoape" width="200"><br>
                Fard de pleoape
            </a>
        </p>

        <p>
            <a href="categorii produse/pag mascara.html">
                <img src="imagini\mascara.jpg" alt="Mascara" width="200"><br>
                Mascara
            </a>
        </p>

        <p>
            <a href="categorii produse/pagina creion.html">
                <img src="imagini\creion.jpg" alt="Creion contur" width="200"><br>
                Creion contur
            </a>
        </p>

        <p>
            <a href="categorii produse/pagina blush.html">
                <img src="imagini\blush.jpg" alt="Blush" width="200"><br>
                Blush
            </a>
        </p>

        <p>
            <a href="categorii produse/pagina highlighter.html">
                <img src="imagini\highlighter.jpg" alt="Highlighter" width="200"><br>
                Highlighter
            </a>
        </p>

        <p>
            <a href="categorii produse/pagina primer.html">
                <img src="imagini\primer.jpg" alt="Primer" width="200"><br>
                Primer
            </a>
        </p>

        <p>
            <a href="categorii produse/pag pudra.html">
                <img src="imagini\pudra.jpg" alt="Pudra" width="200"><br>
                Pudră
            </a>
        </p>

        <p>
            <a href="categorii produse/pagina demachiant.html">
                <img src="imagini\demachiant.jpg" alt="Demachiant" width="200"><br>
                Demachiant
            </a>
        </p>

    </div> 

    <hr>
</body>
</html>