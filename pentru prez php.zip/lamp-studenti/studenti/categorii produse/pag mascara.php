<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Magazin Machiaj</title>
  <link rel="stylesheet" href="stilizare pagini produse.css">
</head>
<body>

    <?php include '../header.php'; ?>

  <h2>Produsele din categoria  : Mascara</h2>
<div class="categorii-container">
  <p>
    <a href="mascara\mascara a.html">
      <img src="mascara\maybelline.jpg" alt="Fond de ten" width="200"><br>
      Maybelline
    </a>
  </p>

  <p>
    <a href="mascara\mascara b.html">
      <img src="mascara\rimmel.jpg" alt="Ruj" width="200"><br>
      Rimmel
    </a>
  </p>

  <p>
    <a href="mascara\mascara c.html">
      <img src="mascara\l'oreal.jpg" alt="Fard de pleoape" width="200"><br>
      L'Oreal
    </a>
  </p>

  <p>
    <a href="mascara\mascara d.html">
      <img src="mascara\lancome.jpg" alt="Mascara" width="200"><br>
      Lancome
    </a>
  </p>
</div>
  <hr>
</body>
</html>
